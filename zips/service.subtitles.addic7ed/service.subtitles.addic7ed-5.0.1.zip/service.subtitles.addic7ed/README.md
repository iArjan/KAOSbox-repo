service.subtitles.addic7ed
==========================

Addic7ed.com subtitle service plugin for XBMC/Kodi

Will not work with Frodo or previous versions of XBMC.

Disclaimer: UNOFFICIAL addon! Not responsible for anything that happens - good, bad, or otherwise if you decide to use this addon.

Git clone this project into the 'addons' folder.
